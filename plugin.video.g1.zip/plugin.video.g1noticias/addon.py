# -*- coding: utf-8 -*-
import sys
import urllib.parse
import xbmcgui
import xbmcplugin
import requests
import xml.etree.ElementTree as ET
import re

# Get the plugin handle
_handle = int(sys.argv[1])
_BASE_URL = sys.argv[0]

# Define G1 RSS Feeds
FEEDS = {
    "G1 - Todas as Notícias": "https://g1.globo.com/dynamo/rss2.xml",
    "G1 - Tecnologia": "https://g1.globo.com/dynamo/tecnologia/rss2.xml",
    "G1 - Economia": "https://g1.globo.com/dynamo/economia/rss2.xml",
    "G1 - Política": "https://g1.globo.com/dynamo/politica/rss2.xml",
    "G1 - Mundo": "https://g1.globo.com/dynamo/mundo/rss2.xml",
    "G1 - Educação": "https://g1.globo.com/dynamo/educacao/rss2.xml",
    "G1 - Carros": "https://g1.globo.com/dynamo/carros/rss2.xml",
}

def build_url(query):
    """Build a URL for the plugin call."""
    return _BASE_URL + "?" + urllib.parse.urlencode(query)

def clean_html(raw_html):
    """Remove HTML tags from a string."""
    cleanr = re.compile('<.*?>|\n')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext.strip()

def fetch_and_parse_rss(feed_url):
    """Fetches an RSS feed and parses it, returning a list of news items."""
    news_items = []
    try:
        response = requests.get(feed_url, timeout=15)
        response.raise_for_status()
        # Try decoding with UTF-8 first, then fallback
        try:
            xml_content = response.content.decode('utf-8', errors='ignore')
        except UnicodeDecodeError:
            xml_content = response.content.decode('iso-8859-1', errors='ignore')

        root = ET.fromstring(xml_content)
        for item in root.findall('./channel/item'):
            title = item.find('title').text if item.find('title') is not None else 'N/A'
            link = item.find('link').text if item.find('link') is not None else 'N/A'
            pub_date_elem = item.find('pubDate')
            pub_date = pub_date_elem.text if pub_date_elem is not None else 'N/A'
            description_elem = item.find('description')
            description = clean_html(description_elem.text) if description_elem is not None and description_elem.text else ''
            
            # Try to get an image from media:content or enclosure
            image = ''
            media_content = item.find('{http://search.yahoo.com/mrss/}content')
            if media_content is not None and 'url' in media_content.attrib:
                image = media_content.attrib['url']
            else:
                enclosure = item.find('enclosure')
                if enclosure is not None and 'url' in enclosure.attrib and enclosure.attrib.get('type', '').startswith('image'):
                    image = enclosure.attrib['url']

            news_items.append({
                'title': title,
                'link': link,
                'pub_date': pub_date,
                'description': description,
                'image': image
            })
    except requests.exceptions.RequestException as e:
        xbmcgui.Dialog().notification('Erro de Rede', f'Falha ao buscar feed: {e}', xbmcgui.NOTIFICATION_ERROR, 5000)
    except ET.ParseError as e:
        xbmcgui.Dialog().notification('Erro de Parsing', f'Falha ao processar XML: {e}', xbmcgui.NOTIFICATION_ERROR, 5000)
    except Exception as e:
        xbmcgui.Dialog().notification('Erro Inesperado', f'{e}', xbmcgui.NOTIFICATION_ERROR, 5000)
    return news_items

def list_feeds():
    """List available RSS feeds as directories."""
    xbmcplugin.setPluginCategory(_handle, 'Feeds G1')
    for feed_name, feed_url in FEEDS.items():
        list_item = xbmcgui.ListItem(label=feed_name)
        list_item.setInfo('video', {'title': feed_name, 'mediatype': 'video'}) # Use video mediatype for consistency
        # Set placeholder icon if available - icon.png should be in the addon root
        list_item.setArt({'icon': 'icon.png', 'thumb': 'icon.png'}) # Assuming icon.png will be added
        
        url = build_url({'mode': 'list_items', 'feed_url': feed_url, 'feed_name': feed_name})
        xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(_handle)

def list_news_items(feed_url, feed_name):
    """List news items from a specific RSS feed."""
    xbmcplugin.setPluginCategory(_handle, feed_name)
    news_items = fetch_and_parse_rss(feed_url)
    if not news_items:
        xbmcgui.Dialog().notification('Feed Vazio', 'Não foi possível carregar notícias.', xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.endOfDirectory(_handle)
        return

    for item in news_items:
        list_item = xbmcgui.ListItem(label=item['title'])
        info = {
            'title': item['title'],
            'plot': item['description'],
            'date': item['pub_date'], # Kodi might parse this if format is standard
            'mediatype': 'video' # Treat as video for consistency, though it opens a link
        }
        list_item.setInfo('video', info)
        # Set artwork if available
        if item['image']:
             list_item.setArt({'thumb': item['image'], 'icon': item['image'], 'fanart': item['image']})
        else: # Placeholder artwork if needed
             list_item.setArt({'icon': 'icon.png', 'thumb': 'icon.png'}) # Assuming icon.png will be added
             pass

        # Set item as playable, action will depend on Kodi's handling of the URL
        # For a web link, it might try to open in a browser addon if configured,
        # or fail if no suitable player is found. This is basic functionality.
        list_item.setProperty('IsPlayable', 'true')
        url = item['link'] # Direct link to the news article
        xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(_handle)

def router(paramstring):
    """Router function that calls other functions based on parameters."""
    params = dict(urllib.parse.parse_qsl(paramstring[1:]))
    mode = params.get('mode')

    if mode is None:
        list_feeds()
    elif mode == 'list_items':
        feed_url = params.get('feed_url')
        feed_name = params.get('feed_name', 'Notícias')
        if feed_url:
            list_news_items(feed_url, feed_name)
        else:
            xbmcgui.Dialog().notification('Erro', 'URL do Feed não especificada.', xbmcgui.NOTIFICATION_ERROR, 5000)
            list_feeds() # Go back to feed list
    # Add other modes here if needed, e.g., playing a video link directly

if __name__ == '__main__':
    router(sys.argv[2])

